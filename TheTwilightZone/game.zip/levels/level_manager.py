from __future__ import annotations

import random
from pathlib import Path

import pygame

from levels.cave_section import (
    CaveSection,
    LevelElement,
)
from levels.level_loader import LevelLoader


class LevelManager:
    """
    Manages cave sections that have been generated and placed
    into the persistent game world.

    Each generated section is an instance of a JSON section template.

    The same JSON template may be used multiple times in the world.
    Each generated instance receives a unique instance ID so that
    runtime state belongs to the generated section instance rather
    than the source JSON filename.

    LevelManager is responsible for:

    - Loading cave section templates.
    - Randomly selecting new section templates.
    - Assigning permanent world positions.
    - Stitching sections together.
    - Remembering previously generated sections.
    - Providing world-space level elements.
    - Tracking the player's active section.
    - Preserving runtime state for each generated section instance.

    Sections are intentionally NOT unloaded.

    This allows the player to:

    - Backtrack through the cave.
    - Return to previously visited areas.
    - Find items they previously dropped.
    - Interact with previously modified sections.

    Future versions can add:

    - Memory limits.
    - Disk-backed persistence.
    - Section compatibility rules.
    - Biome selection.
    - Difficulty progression.
    - Procedural section generation.
    """

    def __init__(
        self,
        data_directory: str | Path,
        available_sections: list[str] | None = None,
    ):
        self.loader = LevelLoader(
            data_directory
        )

        # ----------------------------------------------------------
        # Available section templates
        # ----------------------------------------------------------

        # These are JSON files that can be selected when generating
        # new sections.
        #
        # The same template can be selected more than once.
        #
        # Example:
        #
        # section_01.json
        # section_02.json
        # section_03.json
        # section_04.json

        if available_sections is None:

            available_sections = (
                self._discover_section_files()
            )

        self.available_sections = list(
            available_sections
        )

        # ----------------------------------------------------------
        # Loaded sections
        # ----------------------------------------------------------

        # Each entry represents one generated section instance.

        self.sections: list[
            CaveSection
        ] = []

        # Permanent world offset for every generated section.

        self.section_offsets: list[
            pygame.Vector2
        ] = []

        # Source JSON filename used to generate each section.

        self.section_filenames: list[
            str
        ] = []

        # Unique ID for every generated section instance.

        self.section_instance_ids: list[
            str
        ] = []

        # ----------------------------------------------------------
        # Runtime section state
        # ----------------------------------------------------------

        # Runtime data is stored by unique generated section ID.
        #
        # This is important because the same source JSON file may
        # be used multiple times.
        #
        # Example:
        #
        # section_0001:
        #     dropped_items: [...]
        #
        # section_0002:
        #     dropped_items: [...]
        #
        # Both could have been generated from section_02.json.

        self.section_runtime_state: dict[
            str,
            dict,
        ] = {}

        # ----------------------------------------------------------
        # Active section
        # ----------------------------------------------------------

        # Index into self.sections.

        self.current_section_index = 0

        # ----------------------------------------------------------
        # Generation bookkeeping
        # ----------------------------------------------------------

        # Number of generated section instances.

        self.generated_section_count = 0

        # Filename of the last generated template.
        #
        # Used to prevent immediate repetition.

        self.last_generated_filename: str | None = None

    # ==================================================================
    # INITIAL LOADING
    # ==================================================================

    def load_initial_section(
        self,
        filename: str,
    ) -> CaveSection:
        """
        Load the first cave section into the world.

        The first section is placed at world coordinate (0, 0).

        The initial section is also treated as a generated section
        instance and receives its own unique instance ID.
        """

        section = self.loader.load_section(
            filename
        )

        # ----------------------------------------------------------
        # Start a completely new world
        # ----------------------------------------------------------

        self.sections.clear()

        self.section_offsets.clear()

        self.section_filenames.clear()

        self.section_instance_ids.clear()

        self.section_runtime_state.clear()

        # ----------------------------------------------------------
        # Generate unique instance ID
        # ----------------------------------------------------------

        instance_id = (
            self._create_section_instance_id(
                filename
            )
        )

        # ----------------------------------------------------------
        # Add initial section
        # ----------------------------------------------------------

        self.sections.append(
            section
        )

        self.section_offsets.append(
            pygame.Vector2(
                0,
                0,
            )
        )

        self.section_filenames.append(
            filename
        )

        self.section_instance_ids.append(
            instance_id
        )

        self.section_runtime_state[
            instance_id
        ] = {}

        # ----------------------------------------------------------
        # Generation state
        # ----------------------------------------------------------

        self.current_section_index = 0

        self.generated_section_count = 1

        self.last_generated_filename = (
            filename
        )

        return section

    # ==================================================================
    # RANDOM SECTION SELECTION
    # ==================================================================

    def get_random_section_filename(
        self,
    ) -> str | None:
        """
        Select a random section template.

        The immediately previous template is avoided when possible.

        The same template may still be selected again later.

        Returns:
            The filename of the selected section template,
            or None if no templates are available.
        """

        if not self.available_sections:

            return None

        # ----------------------------------------------------------
        # Avoid immediate repetition
        # ----------------------------------------------------------

        candidates = [
            filename
            for filename in self.available_sections
            if filename
            != self.last_generated_filename
        ]

        # ----------------------------------------------------------
        # Fallback
        # ----------------------------------------------------------

        # If there is only one available section template,
        # it is allowed to repeat.

        if not candidates:

            candidates = list(
                self.available_sections
            )

        return random.choice(
            candidates
        )

    # ==================================================================
    # RANDOM SECTION GENERATION
    # ==================================================================

    def generate_next_random_section(
        self,
    ) -> CaveSection | None:
        """
        Select and generate a random section after the current
        final section.

        The new section is permanently stitched onto the end
        of the generated world.

        Previously generated sections are never moved or removed.

        Returns:
            The newly generated CaveSection,
            or None if no section could be selected.
        """

        filename = (
            self.get_random_section_filename()
        )

        if filename is None:

            return None

        return self.stitch_next_section(
            filename
        )

    # ==================================================================
    # FORWARD STITCHING
    # ==================================================================

    def stitch_next_section(
        self,
        filename: str,
    ) -> CaveSection:
        """
        Load and attach a new section after the current final section.

        The new section's entry is aligned with the current final
        section's exit.

        Once placed, the section's world offset never changes.

        Unlike the old implementation, the same filename may be
        generated multiple times. Each generated instance receives
        a unique runtime identity.
        """

        # ----------------------------------------------------------
        # Empty world
        # ----------------------------------------------------------

        if not self.sections:

            return self.load_initial_section(
                filename
            )

        # ----------------------------------------------------------
        # Current final section
        # ----------------------------------------------------------

        current_section = (
            self.sections[-1]
        )

        current_offset = (
            self.section_offsets[-1]
        )

        # ----------------------------------------------------------
        # Load next section template
        # ----------------------------------------------------------

        next_section = (
            self.loader.load_section(
                filename
            )
        )

        # ----------------------------------------------------------
        # Calculate current exit position
        # ----------------------------------------------------------

        current_exit_world = (
            current_offset
            + current_section.exit_position
        )

        # ----------------------------------------------------------
        # Calculate permanent world offset
        # ----------------------------------------------------------

        next_offset = (
            current_exit_world
            - next_section.entry_position
        )

        # ----------------------------------------------------------
        # Generate unique instance ID
        # ----------------------------------------------------------

        instance_id = (
            self._create_section_instance_id(
                filename
            )
        )

        # ----------------------------------------------------------
        # Add section
        # ----------------------------------------------------------

        self.sections.append(
            next_section
        )

        self.section_offsets.append(
            next_offset
        )

        self.section_filenames.append(
            filename
        )

        self.section_instance_ids.append(
            instance_id
        )

        # ----------------------------------------------------------
        # Create runtime state
        # ----------------------------------------------------------

        self.section_runtime_state[
            instance_id
        ] = {}

        # ----------------------------------------------------------
        # Update generation state
        # ----------------------------------------------------------

        self.generated_section_count += 1

        self.last_generated_filename = (
            filename
        )

        return next_section

    # ==================================================================
    # BACKWARD STITCHING
    # ==================================================================

    def stitch_previous_section(
        self,
        filename: str,
    ) -> CaveSection:
        """
        Load and attach a new section before the current first section.

        The previous section's exit is aligned with the current first
        section's entry.

        Existing sections are never moved.

        This method is primarily useful when restoring or loading
        previously generated world regions.
        """

        # ----------------------------------------------------------
        # Empty world
        # ----------------------------------------------------------

        if not self.sections:

            return self.load_initial_section(
                filename
            )

        # ----------------------------------------------------------
        # Current first section
        # ----------------------------------------------------------

        current_section = (
            self.sections[0]
        )

        current_offset = (
            self.section_offsets[0]
        )

        # ----------------------------------------------------------
        # Load previous section
        # ----------------------------------------------------------

        previous_section = (
            self.loader.load_section(
                filename
            )
        )

        # ----------------------------------------------------------
        # Calculate current entry position
        # ----------------------------------------------------------

        current_entry_world = (
            current_offset
            + current_section.entry_position
        )

        # ----------------------------------------------------------
        # Calculate permanent world offset
        # ----------------------------------------------------------

        previous_offset = (
            current_entry_world
            - previous_section.exit_position
        )

        # ----------------------------------------------------------
        # Generate unique instance ID
        # ----------------------------------------------------------

        instance_id = (
            self._create_section_instance_id(
                filename
            )
        )

        # ----------------------------------------------------------
        # Insert section
        # ----------------------------------------------------------

        self.sections.insert(
            0,
            previous_section,
        )

        self.section_offsets.insert(
            0,
            previous_offset,
        )

        self.section_filenames.insert(
            0,
            filename,
        )

        self.section_instance_ids.insert(
            0,
            instance_id,
        )

        # ----------------------------------------------------------
        # Create runtime state
        # ----------------------------------------------------------

        self.section_runtime_state[
            instance_id
        ] = {}

        # The active section index moves because
        # a section was inserted before it.

        self.current_section_index += 1

        self.generated_section_count += 1

        return previous_section

    # ==================================================================
    # ACTIVE SECTION
    # ==================================================================

    def update_active_section(
        self,
        player_position: pygame.Vector2,
    ):
        """
        Determine which loaded section currently contains the player.

        The active section index is updated when the player moves
        between sections.

        Existing section positions are never changed.
        """

        for index, (
            section,
            offset,
        ) in enumerate(
            zip(
                self.sections,
                self.section_offsets,
            )
        ):

            section_rect = pygame.Rect(
                round(
                    offset.x
                ),
                round(
                    offset.y
                ),
                round(
                    section.width
                ),
                round(
                    section.height
                ),
            )

            if section_rect.collidepoint(
                player_position
            ):

                self.current_section_index = (
                    index
                )

                return index

        return None

    def get_current_section(
        self,
    ) -> CaveSection | None:
        """
        Return the section currently marked as active.
        """

        if not self.sections:

            return None

        if not (
            0
            <= self.current_section_index
            < len(
                self.sections
            )
        ):

            return None

        return self.sections[
            self.current_section_index
        ]

    # ==================================================================
    # WORLD ELEMENTS
    # ==================================================================

    def get_all_elements(
        self,
    ) -> list[LevelElement]:
        """
        Return all currently loaded elements in world coordinates.

        Static section data is never modified.

        Runtime elements are restored from the runtime state belonging
        to each unique generated section instance.
        """

        world_elements = []

        for (
            section,
            offset,
            instance_id,
        ) in zip(
            self.sections,
            self.section_offsets,
            self.section_instance_ids,
        ):

            # ------------------------------------------------------
            # Static section elements
            # ------------------------------------------------------

            for element in section.elements:

                world_element = (
                    self._copy_element(
                        element
                    )
                )

                world_element.position += (
                    offset
                )

                world_elements.append(
                    world_element
                )

            # ------------------------------------------------------
            # Runtime elements
            # ------------------------------------------------------

            runtime_state = (
                self.section_runtime_state.get(
                    instance_id,
                    {},
                )
            )

            dropped_items = (
                runtime_state.get(
                    "dropped_items",
                    [],
                )
            )

            for item in dropped_items:

                runtime_element = (
                    self._copy_element(
                        item
                    )
                )

                runtime_element.position += (
                    offset
                )

                world_elements.append(
                    runtime_element
                )

        return world_elements

    # ==================================================================
    # RUNTIME STATE
    # ==================================================================

    def get_runtime_state(
        self,
        instance_id: str,
    ) -> dict:
        """
        Return mutable runtime state for a generated section instance.

        Runtime state is identified by the unique section instance ID,
        not by the source JSON filename.
        """

        if instance_id not in (
            self.section_runtime_state
        ):

            self.section_runtime_state[
                instance_id
            ] = {}

        return self.section_runtime_state[
            instance_id
        ]

    def get_current_runtime_state(
        self,
    ) -> dict | None:
        """
        Return runtime state for the currently active section.
        """

        if not self.sections:

            return None

        if not (
            0
            <= self.current_section_index
            < len(
                self.section_instance_ids
            )
        ):

            return None

        instance_id = (
            self.section_instance_ids[
                self.current_section_index
            ]
        )

        return self.get_runtime_state(
            instance_id
        )

    def add_dropped_item(
        self,
        instance_id: str,
        item: LevelElement,
    ):
        """
        Store a dropped item in a section's temporary runtime state.

        The item is stored in section-local coordinates.

        Args:
            instance_id:
                Unique ID of the generated section instance.

            item:
                LevelElement representing the dropped item.
        """

        runtime_state = (
            self.get_runtime_state(
                instance_id
            )
        )

        if (
            "dropped_items"
            not in runtime_state
        ):

            runtime_state[
                "dropped_items"
            ] = []

        runtime_state[
            "dropped_items"
        ].append(
            self._copy_element(
                item
            )
        )

    def remove_dropped_item(
        self,
        instance_id: str,
        element_id: str,
    ):
        """
        Remove a dropped item from a section's runtime state.
        """

        runtime_state = (
            self.get_runtime_state(
                instance_id
            )
        )

        dropped_items = (
            runtime_state.get(
                "dropped_items",
                [],
            )
        )

        runtime_state[
            "dropped_items"
        ] = [
            item
            for item in dropped_items
            if item.element_id
            != element_id
        ]

    # ==================================================================
    # WORLD BOUNDS
    # ==================================================================

    def get_world_bounds(
        self,
    ) -> pygame.Rect:
        """
        Return the world-space bounds of all generated sections.

        Since previously generated sections remain loaded, the bounds
        expand as the player explores new territory.
        """

        if not self.sections:

            return pygame.Rect(
                0,
                0,
                0,
                0,
            )

        minimum_x = float(
            "inf"
        )

        minimum_y = float(
            "inf"
        )

        maximum_x = float(
            "-inf"
        )

        maximum_y = float(
            "-inf"
        )

        for section, offset in zip(
            self.sections,
            self.section_offsets,
        ):

            minimum_x = min(
                minimum_x,
                offset.x,
            )

            minimum_y = min(
                minimum_y,
                offset.y,
            )

            maximum_x = max(
                maximum_x,
                offset.x
                + section.width,
            )

            maximum_y = max(
                maximum_y,
                offset.y
                + section.height,
            )

        return pygame.Rect(
            round(
                minimum_x
            ),
            round(
                minimum_y
            ),
            round(
                maximum_x
                - minimum_x
            ),
            round(
                maximum_y
                - minimum_y
            ),
        )

    # ==================================================================
    # ENTRY / EXIT POSITIONS
    # ==================================================================

    def get_last_exit_position(
        self,
    ) -> pygame.Vector2 | None:
        """
        Return the world-space exit position of the final generated
        section.
        """

        if not self.sections:

            return None

        section = (
            self.sections[-1]
        )

        offset = (
            self.section_offsets[-1]
        )

        return (
            offset
            + section.exit_position
        )

    def get_first_entry_position(
        self,
    ) -> pygame.Vector2 | None:
        """
        Return the world-space entry position of the first generated
        section.
        """

        if not self.sections:

            return None

        section = (
            self.sections[0]
        )

        offset = (
            self.section_offsets[0]
        )

        return (
            offset
            + section.entry_position
        )

    # ==================================================================
    # SECTION LOOKUP
    # ==================================================================

    def get_section_index(
        self,
        instance_id: str,
    ) -> int | None:
        """
        Return the loaded list index of a generated section instance.

        Returns None if the instance is not currently loaded.
        """

        try:

            return self.section_instance_ids.index(
                instance_id
            )

        except ValueError:

            return None

    def get_section_instance_id(
        self,
        index: int,
    ) -> str | None:
        """
        Return the unique instance ID associated with a loaded
        section index.
        """

        if not (
            0
            <= index
            < len(
                self.section_instance_ids
            )
        ):

            return None

        return self.section_instance_ids[
            index
        ]

    def get_section_filename(
        self,
        index: int,
    ) -> str | None:
        """
        Return the source JSON filename associated with a loaded
        section index.
        """

        if not (
            0
            <= index
            < len(
                self.section_filenames
            )
        ):

            return None

        return self.section_filenames[
            index
        ]

    def get_loaded_section_count(
        self,
    ) -> int:
        """
        Return the number of generated section instances currently
        cached in memory.
        """

        return len(
            self.sections
        )

    # ==================================================================
    # INTERNAL HELPERS
    # ==================================================================

    def _create_section_instance_id(
        self,
        filename: str,
    ) -> str:
        """
        Create a unique ID for a generated section instance.

        The filename is included for easier debugging, but the
        generated count makes each instance unique.

        Example:

            section_02_0002
            section_02_0003
        """

        self.generated_section_count += 1

        stem = Path(
            filename
        ).stem

        return (
            f"{stem}_"
            f"{self.generated_section_count:04d}"
        )

    def _discover_section_files(
        self,
    ) -> list[str]:
        """
        Automatically discover JSON section templates in the
        level data directory.

        Files are sorted to make debugging and testing predictable.

        Random selection itself is handled separately.
        """

        data_directory = (
            self.loader.data_directory
        )

        if not data_directory.exists():

            return []

        return sorted(
            path.name
            for path in data_directory.glob(
                "*.json"
            )
        )

    @staticmethod
    def _copy_element(
        element: LevelElement,
    ) -> LevelElement:
        """
        Create a deep-enough copy of a LevelElement.

        Geometry vectors are copied so that the original section data
        cannot accidentally be modified.
        """

        return LevelElement(
            element_id=element.element_id,
            element_type=element.element_type,
            position=element.position.copy(),
            points=[
                point.copy()
                for point in element.points
            ],
            properties=dict(
                element.properties
            ),
            material=dict(
                element.material
            ),
        )
